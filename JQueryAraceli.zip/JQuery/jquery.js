$(document).ready(function(){

    $('#button-menu').click(function(){
        if($('#button-menu').attr('class') == 'fas fa-bars'){
            $('#button-menu').removeClass('fas fa-bars').addClass('fas fa-window-close');
            $('.navegacion .menu').css({'left':'0px'});
            $('.navegacion').css({'width':'100%'});

        }else{
            $('#button-menu').removeClass('fas fa-window-close').addClass('fas fa-bars');
            $('.navegacion .menu').css({'left':'-360px'});
            $('.navegacion').css({'width':'0%'});
        }
    });

    $('#slider div:gt(0)').hide();
    setInterval(function(){
      $('#slider div:first-child').fadeOut(0)
         .next('div').fadeIn(1000)
         .end().appendTo('#slider');}, 4000);


         


    $('#mostrar').click(function(){
        $('#prueba').show(1000);
        


    });

    $('#ocultar').click(function(){
        $('#prueba').hide(1000);
        

    });

    $('#tamaño').click(function(){
        $('#prueba').animate({fontSize:'2.4em',width:400,padding:24}, 2500);
       

    });

    $('#mover').click(function(){
        $('#prueba').animate({opacity: "0.1", left: "+=400",fontSize:'1em',width: "200"}, 1200)
		.animate({opacity: "0.4", top: "+=160", height: "20", width: "80",fontSize:'0.5em'}, "slow")
		.animate({opacity: "1", left: "0", width: "260"}, "slow")
		.animate({top: "0",width: "260",fontSize:'1.2em'}, "fast")
		.slideUp()
		.slideDown(1800)
		return false;
        

    });

    $('#estilo').click(function(){
        $('#prueba').css({"background":"lightgreen","color":"purple"});
       

    });



    $("#boton-usuarios").on("click", getUsers);

function getUsers() {
  $.ajax({
    url: 'https://reqres.in/api/users', //servidor
    success: function(respuesta) { //se ejecuta cuando se recibe la información del servidor

      var listaUsuarios = $("#lista-usuarios");
      $.each(respuesta.data, function(index, elemento) {
        listaUsuarios.append(
            '<div>'
          +     '<p>' + elemento.first_name + ' ' + elemento.last_name + '</p>'
          +     '<img src=' + elemento.avatar + '></img>'
          + '</div>'
        );    
      });
    },
    error: function() {
      console.log("No se ha podido obtener la información");
    }
  });
}


$(function(){
    $("#formuploadajax").on("submit", function(e){
        e.preventDefault();
        var f = $(this);
        var formData = new FormData(document.getElementById("formuploadajax"));
        formData.append("dato", "valor");
        //formData.append(f.attr("name"), $(this)[0].files[0]);
        $.ajax({
            url: "recibe.php",
            type: "post",
            dataType: "html",
            data: formData,
            cache: false,
            contentType: false,
     processData: false
        })
            .done(function(res){
                $("#mensaje").html("Respuesta: " + res);
            });
    });
    $("#subir").click(function(){ 
        alert ("Se subió con éxito"); 
        
    })
});

$('#miBoton').on('click', function() { 
    $('ol li:first').appendTo('ol');  
    });





         


});
